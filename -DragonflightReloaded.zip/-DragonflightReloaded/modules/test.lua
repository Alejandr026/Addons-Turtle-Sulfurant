-- =================
-- MODULE TEMPLATE
-- =================

-- DFRL:NewDefaults("TEMPLATE", {
--     enabled = { true },
-- })

-- DFRL:NewMod("TEMPLATE", 1, function()
--     =================
--     SETUP
--     =================
--     local Setup = {
--     }

--     function Setup:Run()
--     end

--     =================
--     INIT
--     =================
--     Setup:Run()

--     =================
--     EXPOSE
--     =================

--     =================
--     CALLBACKS
--     =================
--     local callbacks = {}

--     =================
--     EVENT
--     =================

--     DFRL:NewCallbacks("TEMPLATE", callbacks)
-- end)
